/**
 * @NApiVersion 2.1
 *
 */

define([
    'N/log'
    ], function(
    log
) {

    this.id = '';
    this.location = '';
    this.item = '';
    
    function ParLevel() {
        this.name = 'ParLevel';
    }


    return ParLevel;

});
