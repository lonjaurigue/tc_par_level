define([
    ], function(
) {

    
    
    function ParLevel() {
        this.name = 'ParLevel';
        this.id = '';
        this.location = '';
        this.item = '';
    }


    return ParLevel;

});
